library(shiny)

# Define UI for Predictor vs Response Variable application ----
ui <- fluidPage(

  # App title ----
  titlePanel("BoxPlot : Individual Predictors v RetailPrice"),

  # Sidebar layout with input and output definitions ----
  sidebarLayout(

    # Sidebar panel for inputs ----
    sidebarPanel(

      # Input: Selector for variable to plot against retail price ----
      selectInput("variable", "Variable:",
                  c("Form"="Form",
                    "Yield" = "Yield",
                    "CupEquivalentSize" = "CupEquivalentSize",
                    "CupEquivalentPrice" = "CupEquivalentPrice"
                  
					)),

      # Input: Checkbox for whether outliers should be included ----
      checkboxInput("outliers", "Show outliers", TRUE)

    ),

    # Main panel for displaying outputs ----
    mainPanel(

      # Output: Formatted text for caption ----
      h3(textOutput("caption")),

      # Output: Plot of the requested variable against retail price ----
      plotOutput("RetailPricePlot")

    )
  )
)


fruit$Form <- factor(fruit$Form , labels = c("Form of Fruit","Frozen","Juice","Fresh","Canned"))
fruit <- read.csv("Fruit_Prices_2020.csv")


# Define server logic to plot various variables against RetailPrice ----
server <- function(input, output) {

  # Compute the formula text ----
  # This is in a reactive expression since it is shared by the
  # output$caption and output$RetailPricePlot functions
  formulaText <- reactive({
    paste("RetailPrice ~", input$variable)
  })

  # Return the formula text for printing as a caption ----
  output$caption <- renderText({
    formulaText()
  })

  # Generate a plot of the requested variable against RetailPrice ----
  # and only exclude outliers if requested
  output$RetailPricePlot <- renderPlot({
    boxplot(as.formula(formulaText()),
            data = fruit,
            outline = input$outliers,
            col = "#75AADB", pch = 19)
  })

}



shinyApp(ui, server)